#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MINER_BIN="$SCRIPT_DIR/talero-cpu-miner"
ENV_FILE="$SCRIPT_DIR/.env"

if [[ ! -x "$MINER_BIN" ]]; then
  echo "[error] Binary not found or not executable: $MINER_BIN" >&2
  exit 1
fi

if [[ ! -f "$ENV_FILE" ]]; then
  echo "[error] Missing $ENV_FILE" >&2
  echo "Copy .env.example to .env and set WALLET/WORKER before launching." >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

: "${STRATUM_HOST:?missing STRATUM_HOST in .env}"
: "${STRATUM_PORT:?missing STRATUM_PORT in .env}"
: "${WALLET:?missing WALLET in .env}"
: "${WORKER:?missing WORKER in .env}"

exec "$MINER_BIN"
