# Talero CPU Miner - Installation rapide (Linux x86_64)

## 1) Préparer la config

```bash
cp .env.example .env
nano .env
```

Renseigne au minimum:
- `WALLET=tlro:0x...`
- `WORKER=nom-de-ton-rig`

## 2) Lancer le mineur

```bash
./start_miner.sh
```

## 3) Variables utiles (optionnel)

- `MINER_THREADS` (par défaut: nb de CPU logiques)
- `MINER_SUBMIT_THROTTLE_MS` (par défaut: `0`)
- `MINER_LOG_SHARES` (par défaut: `0`)

## Notes

- Ce package ne contient pas le code source, uniquement ce qui est nécessaire au lancement.
- Si ton antivirus/système retire le bit exécutable, fais:
  `chmod +x talero-cpu-miner start_miner.sh`
