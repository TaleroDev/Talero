#!/usr/bin/env bash
set -euo pipefail
if [ -f .env.example ]; then
  set -a
  source ./.env.example
  set +a
fi
exec ./talero-cpu-miner
