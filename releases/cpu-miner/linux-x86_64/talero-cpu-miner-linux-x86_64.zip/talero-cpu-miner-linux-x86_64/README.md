# Talero CPU Miner (Stratum)

CPU miner for Talero pool Stratum (default `pool.talero.info:3333`).

## Consensus compatibility

Default behavior is **node-consensus compatible**:
- `MINER_POW_IMPL=node`
- `MINER_POW_SEED_MODE=seed`
- `MINER_POW_NONCE_ENDIAN=be`

You can force alternate modes for diagnostics only, but they may be rejected by node-backed pools.

## Build

```bash
cd talero-cpu-miner
cargo build --release
```

## Run

```bash
set -a
source .env.example
set +a

./target/release/talero-cpu-miner
```

## Performance tuning

- `MINER_THREADS` (default = logical CPU count)
- `MINER_SUBMIT_THROTTLE_MS` (default `0`)
- `MINER_LOG_SHARES` (default `0`, verbose hot-path logging)

## Nonce partitioning and duplicate prevention

- `NONCE_PARTITION_MODE`:
  - `worker_job` (default): deterministic nonce partition per `WORKER_UNIQUE_ID + jobId`
  - `legacy`: old global sequential cursor (`start=0`, `stride=1`)
- `WORKER_UNIQUE_ID`: stable per instance/worker unique ID.
  - If unset, miner auto-generates and persists one in `.miner_worker_unique_id`.
- `NONCE_STRIDE` (default `4096`): stride for nonce iteration in `worker_job` mode.
  - Value is normalized to a power-of-two for stable partitioning.
- Restart safety: miner persists a worker epoch and offsets `nonceStart` on each process start to avoid replaying the same range immediately.
- Local anti-replay cache:
  - `SHARE_DEDUP_CAP` (default `50000`)
  - `SHARE_DEDUP_TTL_SECS` (default `1800`)
  - Prevents sending the same `(jobId, nonce)` twice from one instance.

Runtime logs include:
- active nonce plan per job (`nonceStart`, `nonceStride`)
- `duplicate_prevented_total`
- submit rate and accept/stale ratio

## Notes

- Pool currently rejects nonces above `2^53-1` (JS limitation), miner enforces this range.
- `src/bin/mixcheck.rs` is provided to compare hash variants (`node` vs `pool`, BE vs LE).

## Run 3 instances without overlap

```bash
WALLET=tlro:0x... WORKER=rig-01 WORKER_UNIQUE_ID=1 NONCE_STRIDE=4096 NONCE_PARTITION_MODE=worker_job ./target/release/talero-cpu-miner
WALLET=tlro:0x... WORKER=rig-02 WORKER_UNIQUE_ID=2 NONCE_STRIDE=4096 NONCE_PARTITION_MODE=worker_job ./target/release/talero-cpu-miner
WALLET=tlro:0x... WORKER=rig-03 WORKER_UNIQUE_ID=3 NONCE_STRIDE=4096 NONCE_PARTITION_MODE=worker_job ./target/release/talero-cpu-miner
```
